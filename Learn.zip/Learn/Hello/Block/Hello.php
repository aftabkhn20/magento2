<?php

namespace Learn\Hello\Block;


class Hello extends \Magento\Framework\View\Element\Template
{
    /**
     * @return $this
     */
    protected function _prepareLayout()
    {
        return parent::_prepareLayout();
    }

    /**
     * getContentForDisplay
     * @return string
     */
    public function getTesting()
    {
        return __("It's my Custom Learn Module");
    }
}
